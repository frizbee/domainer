<!doctype html>
<!-- paulirish.com/2008/conditional-stylesheets-vs-css-hacks-answer-neither/ -->
<!--[if lt IE 7 ]> <html class="ie6"> <![endif]-->
<!--[if IE 7 ]>    <html class="ie7"> <![endif]-->
<!--[if IE 8 ]>    <html class="ie8"> <![endif]-->
<!--[if IE 9 ]>    <html class="ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]> <html class=""> <![endif]-->
<head>
	<meta charset="utf-8">
	<meta charset=utf-8>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<title>Domain <?php echo $domain; ?> for sale - please contact me for more information</title>

	<meta name="description" content="">
	<meta name="author" content="">

	<!--[if lt IE 9]>
		<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->

	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="assets/css/whhg.css" />
	<link rel="stylesheet" href="assets/css/grid.css">
	<link rel="stylesheet" href="assets/css/styles.css">
	<link rel="stylesheet" href="assets/css/skin-clean.css">
	<style>
	.price { font-size: 50px; color: #72C4B9; text-align: center; }
	.price-title { text-align: center; }
	</style>

	<!-- TODO: uncomment skin styles.
	     Note, you can use another skin found in the "css" folder, or create your own one -->
	<!-- <link rel="stylesheet" href="css/skin-dark.css"> -->

	<!--[if lt IE 9]>
		<link rel="stylesheet" href="css/ie.css">
	<![endif]-->

	<link rel="icon" type="image/png" href="assets/images/favicon.png">
	<link rel="apple-touch-icon" href="assets/images/apple-touch-icon.png">
	<link rel="apple-touch-icon" sizes="72x72" href="assets/images/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="assets/images/apple-touch-icon-114x114.png">

</head>
<body>

	<!--  LOGOTYPE LINE  -->
	<!--  TODO: Change domain name and call to action message below -->
	<div id="Head" class="container">
		<div class="row">
			<div class="col span_16">
				<h1 id="Domain"><?php echo $domain; ?><br>
					<span>The domain is for sale! Take it if you like it!</span></h1>
			</div>

			<div id="Action" class="col span_8">
				<a href="#Offer" class="btn btn-icon btn-block"><i class="icon icon-envelope"></i> Contact me</a>
			</div>
		</div>
	</div>
	<!-- END OF LOGOTYPE LINE  -->

	<!-- CONTENT -->
	<!-- TODO: Change content in the rows/columns below
	     Please note, 24-columns grid is used in the template, so you can reorder the blocks
	     to make, for example, 2-columns layout (use a pair of col span_12) or 4-column one
	     (use 4 copies of col span_6) -->
	<div id="Content" class="container">

		<div class="row special">
			<div class="col span_24">
				<h3 class="align-center">Having owned this domain for a very long time, I'm moving on to other projects and would like to sell it.
					Feel free to contact if interested. Thanks.</h3>
			</div>
		</div>


		<div class="row padding">
			<div class="col span_8">

				<!-- "About seller" text block. Feel free to replace it by any other text or advertisement -->
				<h2 class="price-title">Price</h2>
				<h2 class="price-title"><?php echo $domain; ?></h2>
				<p class="price"><?php echo $amount; ?> &#8364; </p>

				<p></p>

			</div>
			<div class="col span_16">

				<!-- Offer submission form. Please don't change inputs' IDs and names. -->
				<h2>Contact me</h2>
				<div id="Offer">
					<div class="row">
						<div class="col span_12">
							<input type="text" placeholder="Your Name" id="f_name" name="f_name" >
						</div>
						<div class="col span_12">
							<input type="text" placeholder="Your email address" id="f_email" name="f_email" >
						</div>
					</div>
					<div class="row">
						<div class="col span_24">
							<textarea id="f_offer" name="f_offer" rows="10">I would like to buy <?php echo $domain; ?></textarea>
						</div>
					</div>
					<div class="row">
						<div class="col span_24 align-right">
							<button class="btn btn-large" type="button">Send</button>
							<div class="subscribe">
								<input type="checkbox" name="f_subscribe" id="f_subscribe" value="yes"><label for="f_subscribe"> <i></i>Subscribe to our newsletter</label>
							</div>
						</div>
					</div>
				</div> <!-- end of offer form -->

				<!-- Result Messages -->
				<div class="row" id="error_msg">
					<div class="col span_24">
						<b>Sorry, but there were error(s) found with the form you submitted:
						<i></i></b>
						<br><a href="javascript:void(0);" id="new_try">Got it, retry.</a>
					</div>
				</div>
				<div class="row" id="msg">
					<div class="col span_24">
						<b>Offer sent!</b>
						<br><a href="javascript:void(0);" id="new_offer">Make another one?</a>
					</div>
				</div>
				<!-- End of Result Messages -->

			</div> <!-- end of col span_16 -->
		</div> <!-- end of row -->
	</div>
	<!-- END OF CONTENT -->

	<div id="Content-end" class="container"></div>

	<div id="Add" class="container">
		<div class="padding">
			<h2 id="Add-caption">Click here to view more domains <i></i></h2>
			<div class="row" id="Add-domains">
				<div class="col span_24">
					<ul>
						<li><a href="http://thaivilla.com" class="title">thaivilla.com</a><span class="action"><i></i><a href="http://thaivilla.com" class="btn btn-small">Make offer</a></span></li>
						<li><a href="http://ubudvillas.com" class="title">ubudvillas.com</a><span class="action"><i></i><a href="http://ubudvillas.com" class="btn btn-small">Make offer</a></span></li>
						<li><a href="http://surinvillas.com" class="title">surinvillas.com</a><span class="action"><i></i><a href="http://surinvillas.com" class="btn btn-small">Make offer</a></span></li>
					</ul>
					<ul id="More-domains">
						<li><a href='http://aonangkrabi.com' class='title'>aonangkrabi.com</a><span class='action'><i></i><a href='http://aonangkrabi.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://cateredvilla.com' class='title'>cateredvilla.com</a><span class='action'><i></i><a href='http://cateredvilla.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://cateredvillas.com' class='title'>cateredvillas.com</a><span class='action'><i></i><a href='http://cateredvillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://chiangraivillas.com' class='title'>chiangraivillas.com</a><span class='action'><i></i><a href='http://chiangraivillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://colombovilla.com' class='title'>colombovilla.com</a><span class='action'><i></i><a href='http://colombovilla.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://hirevilla.com' class='title'>hirevilla.com</a><span class='action'><i></i><a href='http://hirevilla.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://housethailand.com' class='title'>housethailand.com</a><span class='action'><i></i><a href='http://housethailand.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://jomtienvillas.com' class='title'>jomtienvillas.com</a><span class='action'><i></i><a href='http://jomtienvillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://kalimvilla.com' class='title'>kalimvilla.com</a><span class='action'><i></i><a href='http://kalimvilla.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://kalimvillas.com' class='title'>kalimvillas.com</a><span class='action'><i></i><a href='http://kalimvillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://kamalavilla.com' class='title'>kamalavilla.com</a><span class='action'><i></i><a href='http://kamalavilla.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://kamalavillas.com' class='title'>kamalavillas.com</a><span class='action'><i></i><a href='http://kamalavillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://kaolakvilla.com' class='title'>kaolakvilla.com</a><span class='action'><i></i><a href='http://kaolakvilla.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://kaolakvillas.com' class='title'>kaolakvillas.com</a><span class='action'><i></i><a href='http://kaolakvillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://karonvillas.com' class='title'>karonvillas.com</a><span class='action'><i></i><a href='http://karonvillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://kathuvilla.com' class='title'>kathuvilla.com</a><span class='action'><i></i><a href='http://kathuvilla.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://kathuvillas.com' class='title'>kathuvillas.com</a><span class='action'><i></i><a href='http://kathuvillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://kolantavilla.com' class='title'>kolantavilla.com</a><span class='action'><i></i><a href='http://kolantavilla.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://kolantavillas.com' class='title'>kolantavillas.com</a><span class='action'><i></i><a href='http://kolantavillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://krabi.rentals' class='title'>krabi.rentals</a><span class='action'><i></i><a href='http://krabi.rentals' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://krabiaccommodations.com' class='title'>krabiaccommodations.com</a><span class='action'><i></i><a href='http://krabiaccommodations.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://krabialarms.com' class='title'>krabialarms.com</a><span class='action'><i></i><a href='http://krabialarms.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://krabiarchitect.com' class='title'>krabiarchitect.com</a><span class='action'><i></i><a href='http://krabiarchitect.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://krabiarchitects.com' class='title'>krabiarchitects.com</a><span class='action'><i></i><a href='http://krabiarchitects.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://krabibay.com' class='title'>krabibay.com</a><span class='action'><i></i><a href='http://krabibay.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://krabibeaches.com' class='title'>krabibeaches.com</a><span class='action'><i></i><a href='http://krabibeaches.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://krabibeachvilla.com' class='title'>krabibeachvilla.com</a><span class='action'><i></i><a href='http://krabibeachvilla.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://krabibeachvillas.com' class='title'>krabibeachvillas.com</a><span class='action'><i></i><a href='http://krabibeachvillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://krabibuilder.com' class='title'>krabibuilder.com</a><span class='action'><i></i><a href='http://krabibuilder.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://krabicontractor.com' class='title'>krabicontractor.com</a><span class='action'><i></i><a href='http://krabicontractor.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://krabideveloper.com' class='title'>krabideveloper.com</a><span class='action'><i></i><a href='http://krabideveloper.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://krabiestates.com' class='title'>krabiestates.com</a><span class='action'><i></i><a href='http://krabiestates.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://krabiholidayvillas.com' class='title'>krabiholidayvillas.com</a><span class='action'><i></i><a href='http://krabiholidayvillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://krabiphoto.com' class='title'>krabiphoto.com</a><span class='action'><i></i><a href='http://krabiphoto.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://krabiphotos.com' class='title'>krabiphotos.com</a><span class='action'><i></i><a href='http://krabiphotos.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://krabipoolvillas.com' class='title'>krabipoolvillas.com</a><span class='action'><i></i><a href='http://krabipoolvillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://krabirentals.com' class='title'>krabirentals.com</a><span class='action'><i></i><a href='http://krabirentals.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://krabispas.com' class='title'>krabispas.com</a><span class='action'><i></i><a href='http://krabispas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://krabiweather.com' class='title'>krabiweather.com</a><span class='action'><i></i><a href='http://krabiweather.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://lanta-villa.com' class='title'>lanta-villa.com</a><span class='action'><i></i><a href='http://lanta-villa.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://phiphivilla.com' class='title'>phiphivilla.com</a><span class='action'><i></i><a href='http://phiphivilla.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://phiphivillas.com' class='title'>phiphivillas.com</a><span class='action'><i></i><a href='http://phiphivillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://phuketarchitect.com' class='title'>phuketarchitect.com</a><span class='action'><i></i><a href='http://phuketarchitect.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://phukethouses.com' class='title'>phukethouses.com</a><span class='action'><i></i><a href='http://phukethouses.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://rawaivillas.com' class='title'>rawaivillas.com</a><span class='action'><i></i><a href='http://rawaivillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://rayongvillas.com' class='title'>rayongvillas.com</a><span class='action'><i></i><a href='http://rayongvillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://resortsvillas.com' class='title'>resortsvillas.com</a><span class='action'><i></i><a href='http://resortsvillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://servicedvilla.com' class='title'>servicedvilla.com</a><span class='action'><i></i><a href='http://servicedvilla.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://siam.villas' class='title'>siam.villas</a><span class='action'><i></i><a href='http://siam.villas' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://surinvilla.com' class='title'>surinvilla.com</a><span class='action'><i></i><a href='http://surinvilla.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://surinvillas.com' class='title'>surinvillas.com</a><span class='action'><i></i><a href='http://surinvillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://thailandphuket.com' class='title'>thailandphuket.com</a><span class='action'><i></i><a href='http://thailandphuket.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://thaivilla.com' class='title'>thaivilla.com</a><span class='action'><i></i><a href='http://thaivilla.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://thalanevilla.com' class='title'>thalanevilla.com</a><span class='action'><i></i><a href='http://thalanevilla.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://thalanevillas.com' class='title'>thalanevillas.com</a><span class='action'><i></i><a href='http://thalanevillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://thalangvilla.com' class='title'>thalangvilla.com</a><span class='action'><i></i><a href='http://thalangvilla.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://thalangvillas.com' class='title'>thalangvillas.com</a><span class='action'><i></i><a href='http://thalangvillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://trangvillas.com' class='title'>trangvillas.com</a><span class='action'><i></i><a href='http://trangvillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://travelkohlanta.com' class='title'>travelkohlanta.com</a><span class='action'><i></i><a href='http://travelkohlanta.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://travelkolanta.com' class='title'>travelkolanta.com</a><span class='action'><i></i><a href='http://travelkolanta.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://travelkrabi.com' class='title'>travelkrabi.com</a><span class='action'><i></i><a href='http://travelkrabi.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://ubudvillas.com' class='title'>ubudvillas.com</a><span class='action'><i></i><a href='http://ubudvillas.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://villa-krabi.com' class='title'>villa-krabi.com</a><span class='action'><i></i><a href='http://villa-krabi.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://villalanta.com' class='title'>villalanta.com</a><span class='action'><i></i><a href='http://villalanta.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://villas-krabi.com' class='title'>villas-krabi.com</a><span class='action'><i></i><a href='http://villas-krabi.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://villasreviews.com' class='title'>villasreviews.com</a><span class='action'><i></i><a href='http://villasreviews.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://villasthai.com' class='title'>villasthai.com</a><span class='action'><i></i><a href='http://villasthai.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://yamuvilla.com' class='title'>yamuvilla.com</a><span class='action'><i></i><a href='http://yamuvilla.com' class='btn btn-small'>Make offer</a></span></li>
<li><a href='http://yamuvillas.com' class='title'>yamuvillas.com</a><span class='action'><i></i><a href='http://yamuvillas.com' class='btn btn-small'>Make offer</a></span></li>
					</ul>
					<p class="more"></p>
				</div>
			</div>
		</div>
		<hr>
	</div>


	<div id="Footer" class="container">
		<div class="row top">
			<div class="col span_16"></div>
			<div class="col span_8 align-right"></div>
		</div>
	</div>

<!-- TODO: In order to track visits, insert google analytics code here -->


<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="assets/js/main.js"></script>

</body>
</html>
