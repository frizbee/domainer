Domainer - single-page HTML template for domainers
=============

Domainer free, responsive, single-page HTML template helpfull to anyone who is selling domain names.
So, if you are one of such people, please check out the demo at http://www.gettemplate.com/demo/domainer


License
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/


Features
-----------

* Clean, fat-free HTML and CSS code
* Responsive design
* Built-in placeholders for ADs


Bug tracker
-----------

Found a bug? Please create an issue here on GitHub! 
https://github.com/pozh/Domainer/issues



Credits
-------
* Design and development: **Sergey Pozhilov** - http://pozhilov.com
* Photo used in template: **Pixabay** - http://pixabay.com/en/server-room-datacenter-network-90389/
* More free templates by Sergey: http://gettemplate.com
